package com.ticketBookingApp.service;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.ticketBookingApp.entity.Users;
import com.ticketBookingApp.repository.UserRepo;

@Service
public class CustomerUserDetailsService implements UserDetailsService {
	
	private final UserRepo userRepo;

	public CustomerUserDetailsService(UserRepo userRepo) {
		
		this.userRepo = userRepo;
	}
	
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException
	{
		Users user = userRepo.findByEmail(email.trim().toLowerCase()).orElseThrow(()-> new UsernameNotFoundException(
				"User not found!"
					)
				);
		
		return User.withUsername(user.getEmail())
				.password(user.getPasswordHash())
				.roles("USER")
				.build();
	}
	
}
