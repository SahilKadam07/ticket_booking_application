package com.ticketBookingApp.controller;

import java.util.List;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ticketBookingApp.entity.Booking;
import com.ticketBookingApp.entity.Train;
import com.ticketBookingApp.repository.BookingRepository;
import com.ticketBookingApp.repository.TrainRepo;

@Controller
public class BookingController {
	
	private final BookingRepository bookingRepository;
	
	private final TrainRepo trainRepo;

	public BookingController(BookingRepository bookingRepository, TrainRepo trainRepo) {
		
		this.bookingRepository = bookingRepository;
		this.trainRepo = trainRepo;
	}
	
	@GetMapping("/book-train/{id}")
	public String showBookingPage(@PathVariable("id") Integer id, Model model)
	{
		Train train = trainRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Train not found"));
		
		model.addAttribute("train", train);
		
		return "book-train";
	}
	
	@PostMapping("/book-train/{id}")
	public String bookTrain(@PathVariable("id") Integer id, @RequestParam String passengerName, Authentication authentication)
	{
		if(passengerName == null || passengerName.trim().isEmpty())
		{
			return "redirect:/book-train/" + id + "?error=passenger";
		}
		
		Train train = trainRepo.findById(id).orElseThrow(()-> new IllegalArgumentException("Train not found"));
		
		Booking booking = new Booking();
		
		booking.setPassengerName(passengerName.trim());
		booking.setBookedBy(authentication.getName());
		booking.setTrain(train);
		
		bookingRepository.save(booking);
		
		return "redirect:/my-bookings?success";
	}
	
	@GetMapping("/my-bookings")
	public String myBookings(Authentication authentication, Model model)
	{
		List<Booking> bookings = bookingRepository.findByBookedByOrderByBookingIdDesc(authentication.getName());
		
		model.addAttribute("bookings", bookings);
		
		return "my-bookings";
	}
	
}
