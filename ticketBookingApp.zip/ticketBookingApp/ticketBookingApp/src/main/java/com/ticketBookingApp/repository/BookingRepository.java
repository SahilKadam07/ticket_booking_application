package com.ticketBookingApp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ticketBookingApp.entity.Booking;

public interface BookingRepository extends JpaRepository<Booking, Long>{
	
	List<Booking> findByBookedByOrderByBookingIdDesc(String bookedBy);
	
	

}
