package com.ticketBookingApp.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.ticketBookingApp.entity.Users;
import com.ticketBookingApp.repository.UserRepo;

import jakarta.transaction.Transactional;

@Service
public class RegistrationService {
	
	private final UserRepo userRepo;
	
	private final PasswordEncoder passwordEncoder;

	public RegistrationService(UserRepo userRepo, PasswordEncoder passwordEncoder) {
		this.userRepo = userRepo;
		this.passwordEncoder = passwordEncoder;
	}
	
	@Transactional
	public void register(String name, String email, String phone, String password)
	{
		String normalizedEmail = email.trim().toLowerCase();
		
		if(userRepo.existsByEmail(normalizedEmail))
		{
			throw new IllegalArgumentException("This email is already registered.");
		}
		
		Users user = new Users();
		
		user.setName(name.trim());
		user.setEmail(normalizedEmail);
		user.setPhone(phone);
		
		user.setPasswordHash(passwordEncoder.encode(password));
		
		userRepo.saveAndFlush(user);
		
	}
	
	
	
		

}
