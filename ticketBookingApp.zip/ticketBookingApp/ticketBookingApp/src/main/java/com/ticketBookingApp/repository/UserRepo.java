package com.ticketBookingApp.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ticketBookingApp.entity.Users;

public interface UserRepo extends JpaRepository<Users, Long>{
	
	Optional<Users> findByEmail(String email);
	
	boolean existsByEmail(String email);

}
