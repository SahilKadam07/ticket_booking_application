package com.ticketBookingApp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ticketBookingApp.service.RegistrationService;


@Controller
public class AuthController {
	
	private final RegistrationService registrationService;

	public AuthController(RegistrationService registrationService) {
		
		this.registrationService = registrationService;
	}
	
	@GetMapping("/register")
	public String showRegisterPage()
	{
		return "register";
	}
	
	@PostMapping("/register")
	public String register(@RequestParam String name,
	@RequestParam String email,
	@RequestParam String phone,
	@RequestParam String password,
	@RequestParam String confirmPassword,
	RedirectAttributes redirectAttributes)
	{
		if(!password.equals(confirmPassword)) {
			redirectAttributes.addFlashAttribute(
					"error",
					"Password do not match."

					);
			return "redirect:/register";
		}
		if(password.length()<8) {
			redirectAttributes.addFlashAttribute(
					"error",
					"Password must be 8 characters."

					);
			return "redirect:/register";
		}
		
		try {
			
			registrationService.register(name, email, phone, confirmPassword);
		}
		catch(IllegalArgumentException ex)
		{
			redirectAttributes.addFlashAttribute(
					"error", ex.getMessage()
					);
			return "redirect:/register";
		}
		
		redirectAttributes.addFlashAttribute(

				"success",
				"Registration successful. Please log in."
				);
		
		return "redirect:/login";
		
	}
	
	@GetMapping("/login")
	public String showLoginPage()
	{
		return "login";
	}
	
	@GetMapping("/home")
	public String showHomePage(org.springframework.ui.Model model)
	{
		return "home";
	}

}
