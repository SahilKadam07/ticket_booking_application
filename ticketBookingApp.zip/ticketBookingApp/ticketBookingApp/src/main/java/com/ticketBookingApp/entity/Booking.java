package com.ticketBookingApp.entity;

import javax.annotation.processing.Generated;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "bookings")
public class Booking {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long bookingId;
	
	
	private String passengerName;
	
	private String bookedBy;
	
	@ManyToOne
	@JoinColumn(name="train_id", nullable = false)
	private Train train;

	public Booking() {
		
	}

	public Booking(long bookingId, String passengerName, String bookedBy, Train train) {
		super();
		this.bookingId = bookingId;
		this.passengerName = passengerName;
		this.bookedBy = bookedBy;
		this.train = train;
	}

	public long getBookingId() {
		return bookingId;
	}

	public void setBookingId(long bookingId) {
		this.bookingId = bookingId;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public String getBookedBy() {
		return bookedBy;
	}

	public void setBookedBy(String bookedBy) {
		this.bookedBy = bookedBy;
	}

	public Train getTrain() {
		return train;
	}

	public void setTrain(Train train) {
		this.train = train;
	}

	public void setPassengerName1(String trim) {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
